coder: @simosaper11
fb: https://www.facebook.com/simosaper11

channel: @simosaper

share and join for other tools :)


install requests in python3 
command:
pip install requests bs4 colorama
python saper.py


in python2 

python2 on.py