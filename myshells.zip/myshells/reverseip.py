import requests
import os
from colorama import Fore
from urlextract import URLExtract

yl = Fore.YELLOW
red = Fore.RED
gr = Fore.GREEN


headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US'}
def banner():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

    print(red + "××××××××××××××××××××××××××××××××××××××××××××××××××××××××")
    print(gr  + "×                                                      ×")
    print(gr  + "×                  REVERSE IP VIP                      ×")
    print(gr  + "×               CODED BY M0H@MeD S@PeR                 ×")
    print(gr  + "×               TEAM - BLACK HAT EGYPT                 ×")
    print(gr  + "×                   TG @simosaper                      ×")
    print(red + "××××××××××××××××××××××××××××××××××××××××××××××××××××××××")
    print(gr  +  "       -MASS FIND WEBSITE HOSTED ON SAME IP-\n         ")

def grab():
    sites = input("ENTER FILE OF IPS :")
    Files = open(sites)
    for i in Files.readlines():
        site = i.strip()
        try:
            site = site.strip()
            resp = requests.get('https://askdns.com/ip/' + site, headers=headers ).text
            if "Domain Neighbors" in resp:
                extractor = URLExtract()
                ext = extractor.find_urls(resp)
                ext = ext[5:-3]
                for i in ext:
                    print(i)
                    f = open("saper.txt", 'a')
                    f.write(i + '\n')
            else:
                print("Dead IP")
        except:
            pass

banner()
grab()


