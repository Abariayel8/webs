<h1>XAttacker Tool 3.0</h1>
<p><a href="https://github.com/Nano1337824/XAttacker-3.0V-Remade/"><img src="https://img.shields.io/badge/XAttacker-3.0-brightgreen.svg" alt="Version" data-canonical-src="https://img.shields.io/badge/XAttacker-3.0-brightgreen.svg?maxAge=259200" style="max-width:100%;"></a>
<a href="https://github.com/Nano1337824/XAttacker-3.0V-Remade/"><img src="https://img.shields.io/badge/Release-Stable-orange.svg" alt="Stage" data-canonical-src="https://img.shields.io/badge/Release-Stable-orange.svg" style="max-width:100%;"></a>
<a href="https://github.com/Nano1337824/XAttacker-3.0V-Remade/"><img src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" alt="Build" data-canonical-src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" style="max-width:100%;"></a></p>
X Attacker Tool ☣ Website Vulnerability Scanner & Auto Exploiter
You can use this tool to check the security by finding the vulnerability in your website or you can use this tool to Get Shells | Sends | Deface | cPanels | Databases

All Credits To The Org Owners i Remade The API and added New Exploits To Joomla And Wordpress,

<img src="https://imgur.com/Z2chTFn.jpg" data-canonical-src="https://imgur.com/Z2chTFn.jpg" style="max-width:100%;">

<h2>Video</h2>
<a href="https://www.youtube.com/watch?v=NC4_5Q9t-bA"><img src="https://imgur.com/gv78WQk.jpg" style="max-width:100%;"></a>


## Installation [Linux](https://wikipedia.org/wiki/Linux) [![alt tag](http://icons.iconarchive.com/icons/dakirby309/simply-styled/32/OS-Linux-icon.png)](https://fr.wikipedia.org/wiki/Linux)

```bash
apt-get install python
pip install requests
pip install colorama
git clone https://github.com/Nano1337824/XAttacker-3.0.git
cd XAttacker
perl XAttacker.pl
```

Follow This Video [SSTec Tutorials](https://youtu.be/3S-R3c-v-LI)

## Installation [Android](https://wikipedia.org/wiki/Android) [![alt tag](https://cdn1.iconfinder.com/data/icons/logotypes/32/android-32.png)](https://fr.wikipedia.org/wiki/Android)

Download [Termux](https://play.google.com/store/apps/details?id=com.termux)

```bash
apt-get install python
apt-get install python-pip
pip install requests
pip install colorama
git clone https://github.com/Nano1337824/XAttacker-3.0.git
cd XAttacker
chmod +x termux-install.sh
bash termux-install.sh
```

Follow This Video [Psyco Tutorials](https://youtu.be/3S-R3c-v-LI)

## Installation [Windows ](https://wikipedia.org/wiki/Microsoft_Windows)[![alt tag](http://icons.iconarchive.com/icons/tatice/cristal-intense/32/Windows-icon.png)](https://fr.wikipedia.org/wiki/Microsoft_Windows)
```bash
Download python
Downlaod pip
Download Perl
Download XAttacker
Extract XAttacker into Desktop
Open CMD and type the following commands:
cd Desktop/XAttacker-master/
perl XAttacker.pl
```


<h2>Version</h2>
<strong>Current version is 3.0</strong>
<strong>What's New </strong>
<br>• Uploadify > Word Press Exploit 2018
<br>• wpsc > Wordpress Exploit 2019 
<br>• Fixed API Pulls More Vuln Sites Off More Search eng
<br>• added Zone-h Scraper
<br>• added Private Tool
<br>• Admin Panel Finder
<br>• Added More Colors
<br>• Added a Joomla File Upload Exploit
<br>• More Coming Soon </br>

<h2>WARNING</h2>
<strong>Warning Scanning too many servers in a short period may lead your internet provider to shut it down </strong>

<img src="https://imgur.com/38FhaWg.jpg" data-canonical-src="https://imgur.com/38FhaWg.jpg" style="max-width:100%;">
##This Project Has Been Disconnected until i get the time to work on it
